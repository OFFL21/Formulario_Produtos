package dao;

import model.Produto;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;

public class ProdutoDAO {
	
	private String jdbcURL ="jdbc:mysql://localhost:3306/loja ";
	private String jdbcUsername = "root";
	private String jdbcPassword = "Luisfellipe21.";
	
	private static final String INSERT_PRODUTO_SQL = "INSERT INTO produto (nome, descricao, preco, data_inclusao)VALUES(?,?,?,?)";
	private static final String SELECT_PRODUTO_BY_ID = "SELECT nome, descricao, preco, data_inclusao FROM produto WHERE id=?";
	private static final String 	SELECT_ALL_PRODUTO = "SELECT * FROM produto";
    private static final String DELETE_PRODUTO_SQL = "DELETE FROM produto WHERE id = ?";
    private static final String UPDATE_PRODUTO_SQL = "UPDATE produto SET  nome = ?, descricao= ?, preco =?, data_inclusao = ? WHERE id = ?";

    protected Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return connection;
    }

    // Métodos CRUD

    public void insertProduto(Produto produto) throws SQLException {
        try (Connection connection = getConnection(); 
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_PRODUTO_SQL)) {
            preparedStatement.setString(1, produto.getNome());
            preparedStatement.setString(2, produto.getDescricao());
            preparedStatement.setFloat(3, produto.getPreco());
            preparedStatement.setDate(4, produto.getData_inclusao());
            preparedStatement.executeUpdate();
        }
    }

    public Produto selectProduto(int id) {
        Produto produto = null;
        try (Connection connection = getConnection(); 
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_PRODUTO_BY_ID)) {
            preparedStatement.setInt(1, id);
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                String nome = rs.getString("nome");
                String descricao = rs.getString("descricao");
                float preco = rs.getFloat("preco");
                Date data_inclusao = rs.getDate("data_inclusao");
                produto = new Produto ( nome, descricao, preco, data_inclusao);
                produto.setId(id);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return produto;
    }

    public List<Produto> selectAllProduto() {
        List<Produto> produtos = new ArrayList<>();
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_PRODUTO)) {
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String nome = rs.getString("nome");
                String descricao = rs.getString("descricao");
                float preco = rs.getFloat("preco");
                Date data_inclusao = rs.getDate("data_inclusao");
                Produto produto = new Produto(nome, descricao, preco, data_inclusao);
                produto.setId(id);  // Setando o id corretamente no objeto Produto
                produtos.add(produto);  // Adicionando o objeto Produto à lista
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return produtos;  // Retorna a lista de produtos
    }


    public boolean updateProduto(Produto produto) throws SQLException {
        boolean rowUpdated;
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(UPDATE_PRODUTO_SQL)) {
        		statement.setString(1, produto.getNome());
        		statement.setString(2, produto.getDescricao());
        		statement.setFloat(3, produto.getPreco());
        		statement.setDate(4, produto.getData_inclusao());
        		statement.setInt(5, produto.getId());
        		
            rowUpdated = statement.executeUpdate() > 0;
        }
        return rowUpdated;
    }

    public boolean deleteProduto(int id) throws SQLException {
        boolean rowDeleted;
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(DELETE_PRODUTO_SQL)) {
            statement.setInt(1, id);
            rowDeleted = statement.executeUpdate() > 0;
        }
        return rowDeleted;
    }
    
    public List<Produto> searchProdutoByName(String name) throws SQLException {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Nome do produto não pode ser vazio.");
        }

        List<Produto> listProduto = new ArrayList<>();
        String sql = "SELECT * FROM produto WHERE nome LIKE ?";

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, "%" + name + "%"); // Configura o parâmetro da consulta.
            try (ResultSet rs = statement.executeQuery()) { // ResultSet fechado automaticamente.
                while (rs.next()) {
                    // Obter os dados do banco, incluindo o ID
                    int id = rs.getInt("id"); // Aqui você recupera o ID.
                    String nome = rs.getString("nome");
                    String descricao = rs.getString("descricao");
                    float preco = rs.getFloat("preco");
                    Date dataInclusao = rs.getDate("data_inclusao");

                    // Cria o objeto Produto e define o ID.
                    Produto produto = new Produto(nome, descricao, preco, dataInclusao);
                    produto.setId(id); // Define o ID que faltava.

                    // Adiciona o produto à lista.
                    listProduto.add(produto);
                }
            }
        }
        return listProduto; // Retorna a lista (pode ser vazia).
    }
}

	
	


