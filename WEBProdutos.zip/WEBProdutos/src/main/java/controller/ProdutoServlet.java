package controller;

import dao.ProdutoDAO;
import model.Produto;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@WebServlet("/produto")
public class ProdutoServlet extends HttpServlet {
    private ProdutoDAO produtoDAO;

    public void init() {
        // Instanciando ProdutoDAO
        produtoDAO = new ProdutoDAO();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) {
            action = "list";  // Define um valor padrão
        }
        try {
            switch (action) {
                case "new":
                    showNewForm(request, response);
                    break;
                case "insert":
                    insertProduto(request, response);
                    break;
                case "delete":
                    deleteProduto(request, response);
                    break;
                case "edit":
                    showEditForm(request, response);
                    break;
                case "update":
                    updateProduto(request, response);
                    break;
                default:
                    listProduto(request, response);
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }

    
    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("produto-form.jsp").forward(request, response);
    }
    
    private void listProduto(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        String search = request.getParameter("search");
        List<Produto> listProduto;

        if (search != null && !search.isEmpty()) {
            // Chamando método por instância
            listProduto = produtoDAO.searchProdutoByName(search);
        } else {
            // Chamando método por instância
            listProduto = produtoDAO.selectAllProduto();
        }
        request.setAttribute("listProduto", listProduto);
        request.getRequestDispatcher("produto-list.jsp").forward(request, response);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        Produto existingProduto = produtoDAO.selectProduto(id); // Usando instância
        request.setAttribute("produto", existingProduto);
        request.getRequestDispatcher("produto-form.jsp").forward(request, response);
    }

    private void insertProduto(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        String nome = request.getParameter("nome");
        String descricao = request.getParameter("descricao");
        Float preco = Float.parseFloat(request.getParameter("preco"));
        String data_inclusao_str = request.getParameter("data_inclusao");

        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date data_inclusao = new java.sql.Date(sdf.parse(data_inclusao_str).getTime());
            Produto novoProduto = new Produto(nome, descricao, preco, (java.sql.Date) data_inclusao);
            produtoDAO.insertProduto(novoProduto); // Usando instância
            response.sendRedirect("produto?action=list");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updateProduto(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String nome = request.getParameter("nome");
        String descricao = request.getParameter("descricao");
        Float preco = Float.parseFloat(request.getParameter("preco"));
        String data_inclusao_str = request.getParameter("data_inclusao");

        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            java.sql.Date data_inclusao = new java.sql.Date(sdf.parse(data_inclusao_str).getTime());
            Produto novoProduto = new Produto(nome, descricao, preco, data_inclusao);
            novoProduto.setId(id);
            produtoDAO.updateProduto(novoProduto); // Usando instância
            response.sendRedirect("produto?action=list");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void deleteProduto(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        produtoDAO.deleteProduto(id); // Usando instância
        response.sendRedirect("produto?action=list");
    }
}
