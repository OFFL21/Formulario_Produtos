package model;

import java.sql.Date;

public class Produto {
	private int id;
	private String nome;
	private String descricao;
	private float preco;
	private Date data_inclusao;

	// Construtores
	public Produto() {
	}

	public Produto( String nome, String descricao, float preco, Date data_inclusao) {
		this.nome = nome;
		this.descricao = descricao;
		this.preco = preco;
		this.data_inclusao = data_inclusao;
	}

	// Getters e Setters
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public float getPreco() {
		return preco;
	}

	public void setPreco(float preco) {
		this.preco = preco;
	}

	public Date getData_inclusao() {
		return data_inclusao;
	}

	public void setData_inclusao(Date data_inclusao) {
		this.data_inclusao = data_inclusao;
	}
}
